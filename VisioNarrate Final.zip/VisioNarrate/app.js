const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config();
const fs = require('fs');

// Initialize GoogleGenerativeAI with API key
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

// Function to convert file information to GoogleGenerativeAI.Part object
function fileToGenerativePart(path, mimeType) {
    return {
        inlineData: {
            data: Buffer.from(fs.readFileSync(path)).toString("base64"),
            mimeType
        },
    };
}

// Function to generate text from a prompt
async function textToText() {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const prompt = "write a story about the legendary love story of Abhinav  and () in 200 words";
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    console.log(text);
}

// Function to generate text from text and image input
async function textAndImageToText() {
    const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });
    const prompt = "What's different between these pictures?";
    const imageParts = [
        fileToGenerativePart("recap.jpg", "image/jpeg"),
        fileToGenerativePart("group.jpeg", "image/jpeg"),
    ];
    const result = await model.generateContent([prompt, ...imageParts]);
    const response = await result.response;
    const text = response.text();
    console.log(text);
}

// Function to chat with context of previous conversations
async function textToChat() {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const chat = model.startChat({
        history: [
            {
                role: "user",
                parts: [{ text: "Hello, I have 2 dogs in my house." }],
            },
            {
                role: "model",
                parts: [{ text: "Great to meet you. What would you like to know?" }],
            },
        ],
        generationConfig: {
            maxOutputTokens: 50,
        },
    });
    const msg = "How many paws are in my house?";
    const result = await chat.sendMessage(msg);
    const response = await result.response;
    const text = response.text();
    console.log(text);
}

// Function to create embeddings
async function createEmbeddings() {
    const model = genAI.getGenerativeModel({ model: "embedding-001" });
    const text = "Embedding any text.";
    const result = await model.embedContent(text);
    const embedding = result.embedding;
    console.log(embedding.values);
}

// Entry point to run the different functionalities
async function run() {
    // Uncomment the function calls below to execute desired functionality
     //await textToText();
     //await textAndImageToText();
    // await textToChat();
    // await createEmbeddings();
}

// Execute the run function
run();


