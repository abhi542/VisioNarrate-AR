const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config()
// Access your API key as an environment variable (see "Set up your API key" above)
const fs = require('fs')

const genAI = new GoogleGenerativeAI(process.env.API_KEY);


// ...

const model = genAI.getGenerativeModel({ model: "gemini-pro-vision"});

// ...

// TEXT TO TEXT - use 'gemini-pro' in const model
// async function run() {
//   // For text-only input, use the gemini-pro model
//   const model = genAI.getGenerativeModel({ model: "gemini-pro"});

//   const prompt = "write a story about the legendary love story of Abhinav and () in 200 words"

//   const result = await model.generateContent(prompt);
//   const response = await result.response;
//   const text = response.text();
//   console.log(text);
// }

// run();



// // TEXT + IMAGE to TEXT use 'gemini-pro-vision'

// // Converts local file information to a GoogleGenerativeAI.Part object.
// function fileToGenerativePart(path, mimeType) {
//     return {
//       inlineData: {
//         data: Buffer.from(fs.readFileSync(path)).toString("base64"),
//         mimeType
//       },
//     };
//   }


//   async function run() {
//     // For text-and-image input (multimodal), use the gemini-pro-vision model
//     const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });
  
//     const prompt = "What's different between these pictures?";
  
//     const imageParts = [
//       fileToGenerativePart("recap.jpg", "image/jpeg"),
//       fileToGenerativePart("group.jpeg", "image/jpeg"),
//     ];
  
//     const result = await model.generateContent([prompt, ...imageParts]);
//     const response = await result.response;
//     const text = response.text();
//     console.log(text);
//   }
// run();


// // TEXT to Chat with context of prev conversations
// async function run() {
//   // For text-only input, use the gemini-pro model
//   const model = genAI.getGenerativeModel({ model: "gemini-pro"});

//   const chat = model.startChat({
//     history: [
//       {
//         role: "user",
//         parts: [{ text: "Hello, I have 2 dogs in my house." }],
//       },
//       {
//         role: "model",
//         parts: [{ text: "Great to meet you. What would you like to know?" }],
//       },
//     ],
//     generationConfig: {
//       maxOutputTokens: 50,
//     },
//   });

//   const msg = "How many paws are in my house?";

//   const result = await chat.sendMessage(msg);
//   const response = await result.response;
//   const text = response.text();
//   console.log(text);
// }

// run();


// // CREATING EMBEDDINGS using gemin-pro
// async function run() {
//     // For embeddings, use the embedding-001 model
//     const model = genAI.getGenerativeModel({ model: "embedding-001"});
  
//     const text = "Embedding any text."
  
//     const result = await model.embedContent(text);
//     const embedding = result.embedding;
//     console.log(embedding.values);
//   }

// run()

// console.log(model)
